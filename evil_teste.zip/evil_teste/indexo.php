
<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>*Nome da empresa*</title>
    <link rel="stylesheet" href="esqueletum.css"/>
  </head>
  <body>

    <main>
        <!--menu-->
        <div class="css-menu-container">
          <nav class="css-menu" data-type="extendedBox" data-for="menu" data-targetboxid="menu">
            <div class="menu-header"></div>
            <div class="instrucao i8">texto aqui(login)</div>
            <div class="menu-divider m1"></div>
            <a href="esqueleto.html" class="test">test</a>
            <a href="https://github.com/ClaudioJian/CalculadoraFinanceira.git">teste-Github-Link</a>
            <div class="instrucao i9">texto aqui(outras páginas)</div>
            <div class="menu-divider m2"></div>
            <form>
              <input placeholder="test" name="test">
            </form>
            <div class="instrucao i10">texto aqui(histórico)</div>
            <div class="menu-divider m3"></div>
            <div class="resizer" data-direction="e"></div>
          </nav>
          <!--button for open menu-->
          <button style="height: fit-content;" class="img-button">
            <img class="css-img-menu" data-action="open-menu" data-type="extendable" src="image/img_placeholder.jpg" data-openboxid="menu">
          </button>
          <!--button for open calculator-->
          <button class="btn-open-calculator-out">
            <img src="image/img_placeholder.jpg" data-action="open-calculator" data-type="extendable" data-openboxid="calc">
          </button>
        </div>

    </main>
      <script src="menu.js"></script>
  </body>
</html>